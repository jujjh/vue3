<template>
  <h1>게시판</h1>
  <div class="boardWrap">
    <div class="boardTop">

      <p>total {{cache.length}}</p>
      <select v-model="listCunt">
        <option value="2" selected> 2개씩 보기</option>
        <option value="1"> 1개씩 보기</option>
        <option value="3"> 3개씩 보기</option>
      </select>
    </div>
    <div>
      <table class="table">
        <colgroup>
          <col width="70">
          <col width="">
          <col width="120">
          <col width="120">
        </colgroup>
        <thead>
          <tr>
            <th>번호</th>
            <th>제목</th>
            <th>작성자</th>
            <th>등록일</th>
          </tr>
        </thead>
        <tbody>
          <template v-if="list.length > 0">
          <tr v-for="(item, idx) in list" :key="`list-${idx}`">
            <td>{{item.idx}}</td>
            <td>{{item.title}}</td>
            <td>{{item.userName}}</td>
            <td>{{item.regDate.substr(0,10)}}</td>
          </tr>
          </template>
        </tbody>
      </table>
    </div>
    <ul class="pagination">
      <li class="page-item"><a class="page-link" href="#" @click.prevent="pageArrow('first')">First</a></li>
      <li class="page-item"><a class="page-link" href="#" @click.prevent="pageArrow('prev')">Previous</a></li>
      <template v-for="(item, index) in totalPage" :key="`list-${index}`">
        <li class="page-item" :class="{'active' : index+1 == currentPage}"><a class="page-link" href="#" @click.prevent="page(index + 1)">{{index+1}}</a></li>
      </template>
      <li class="page-item"><a class="page-link" href="#" @click.prevent="pageArrow('next')">Next</a></li>
      <li class="page-item"><a class="page-link" href="#" @click.prevent="pageArrow('last')">Last</a></li>
    </ul>
    <div>
      <a href="#" @click.prevent="write" class="btn btn-sm btn-primary">작성</a>
    </div>
    
  </div>
</template>

<script setup>
import router from '@/router'
import axios from 'axios'
import {ref, watch} from 'vue'


const write = () => {
  router.push('/ex/board/write')
}

const list = ref([])
const cache = ref([])
let currentPage = ref(1)
const listCunt = ref('2')
const totalPage = ref()


// 페이징 
const paging =() => {
  if(cache.value.length % listCunt.value == 0 ){
    totalPage.value = cache.value.length / listCunt.value
  } else{
    totalPage.value =  parseInt(cache.value.length / listCunt.value) + 1

  }
}


const getList = () =>{
  
  axios.post('https://studyapi.programrush.co.kr/study/getBoardList')
  .then(res => {
    
    const json = res.data
    if(json.result == "success"){
      //list.value = json.data; 
      cache.value = json.data
      console.log(cache.value)
    }
    list.value = []
    
    let listIdx = (listCunt.value * (currentPage.value -1));
    for(let i= 0; i < listCunt.value; i++ ){      
      if(cache.value.length > listIdx) {
        list.value.push(cache.value[listIdx])
        console.log(listIdx)
        listIdx ++;
      }
    }

    paging()

  })  
}

getList()

const page = (e) =>{
  currentPage.value = e
}

//리스트 갯수 수정시
watch(listCunt,(a, b)  =>{
  //currentPage.value = 1
  getList()
})

//페이지 번호 클릭시
watch(currentPage,(a, b)  =>{
  getList()
})

</script>

<style scoped>
.boardWrap {width:80%;}
.boardTop {display:flex; justify-content: space-between; align-items: center; margin-bottom:20px;}
.pagination {text-align:center}
</style>
