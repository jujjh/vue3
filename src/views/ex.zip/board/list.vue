<template>
  <h1>게시판</h1>

  <div class="tableWrap">
    <table>
      <colgroup>
        <col width="70">
        <col width="">
        <col width="120">
        <col width="120">
      </colgroup>
      <thead>
        <tr>
          <th>번호</th>
          <th>제목</th>
          <th>작성자</th>
          <th>등록일</th>
        </tr>
      </thead>
      <tbody>
        <template v-if="list.length > 0">
        <tr v-for="(item, idx) in list" :key="`list-${idx}`">
          <td>{{item.idx}}</td>
          <td>{{item.title}}</td>
          <td>{{item.userName}}</td>
          <td>{{item.regDate.substr(0,10)}}</td>
        </tr>
        </template>
      </tbody>
    </table>
  </div>
  <div>
    <a href="#" @click.prevent="write" class="btn btn-sm btn-primary">작성</a>
  </div>
    
</template>

<script setup>
import router from '@/router'
import axios from 'axios'
import {ref} from 'vue'


const write = () => {
  router.push('/ex/board/write');
}

const list = ref([]);

const getList = () =>{
  axios.post('https://studyapi.programrush.co.kr/study/getBoardList')
  .then(res => {
    const json = res.data
    if(json.result == "success"){
      list.value = json.data; 
    }
  })  
}

getList()

</script>

<style scoped>
.tableWrap {margin-bottom: 10px;}
.tableWrap table {width:80%; border:2px solid #999; border-width: 1px 0; font-size: 14px;}
.tableWrap table th {padding:10px; }
.tableWrap table td {padding:4px; border-top:1px solid #ddd; }
.tableWrap table td:first-child {text-align: center;}

</style>
