<template>
  <h1>게시판</h1>
  <div class="boardWrap">
    <div class="boardTop">

      <p>total {{cache.length}}</p>
      <select v-model="listCunt">
        <option value="5" selected> 5개씩 보기</option>
        <option value="10"> 10개씩 보기</option>
        <option value="20"> 20개씩 보기</option>
      </select>
    </div>
    <div>
      <table class="table">
        <colgroup>
          <col width="70">
          <col width="">
          <col width="120">
          <col width="120">
        </colgroup>
        <thead>
          <tr>
            <th>번호</th>
            <th>제목</th>
            <th>작성자</th>
            <th>등록일</th>
          </tr>
        </thead>
        <tbody>
          <template v-if="list.length > 0">
          <tr v-for="(item, idx) in list" :key="`list-${idx}`">
            <td>{{item.idx}}</td>
            <td>{{item.title}}</td>
            <td>{{item.userName}}</td>
            <td>{{item.regDate.substr(0,10)}}</td>
          </tr>
          </template>
        </tbody>
      </table>
    </div>
    {{currentPage}} / {{totalPageArry}} / {{totalPage}}
    <ul class="pagination">
      <li class="page-item"><a class="page-link" href="#" @click.prevent="pageArrow('first')">First</a></li>
      <li class="page-item"><a class="page-link" href="#" @click.prevent="pageArrow('prev')">Previous</a></li>
      <template v-for="(item, index) in pageList" :key="`list-${index}`">
        <li class="page-item" :class="{'active' : item == currentPage +1}"><a class="page-link" href="#" @click.prevent="page(item -1)">{{item}}</a></li>
      </template>
      <li class="page-item"><a class="page-link" href="#" @click.prevent="pageArrow('next')">Next</a></li>
      <li class="page-item"><a class="page-link" href="#" @click.prevent="pageArrow('last')">Last</a></li>
    </ul>
    <div>
      <a href="#" @click.prevent="write" class="btn btn-sm btn-primary">작성</a>
    </div>
    
  </div>
</template>

<script setup>
import router from '@/router'
import axios from 'axios'
import {ref, watch} from 'vue'


const write = () => {
  router.push('/ex/board/write')
}

const list = ref([]) //보여지는 리스트
const cache = ref([]) //리스트 전체

const listCunt = ref('5') // 한 페이지에 노출될 게시글 개수

let pageNum = 10 //페이징 갯수
let currentPage = ref(0) //현재페이지
const pageList = ref([]) // 보여지는 페이지
let totalPage = ref(0); //페이지 전체
let totalPageArry =  ref([]) ; //페이지 전체


// 페이징 
const paging =() => {
  pageList.value = [];
  totalPageArry.value = []

  if(cache.value.length % listCunt.value == 0 ){
    totalPage.value = cache.value.length / listCunt.value
  } else{
    totalPage.value =  Math.ceil(cache.value.length / listCunt.value)
  }

  
  for(let i= 0; i<Math.ceil(totalPage.value / 10); i++){
    totalPageArry.value.push([])
    for(let j = 0; j < 10; j++){
      if(totalPage.value > (i*10)+ j){
        totalPageArry.value[i].push(((i*10)+ j +1))
      }
    }
  }

  let pageListStart = Math.floor(currentPage.value / pageNum) * pageNum + parseInt(1)
  for(let i= 0; i<pageNum; i++){   
    
    pageList.value.push(pageListStart)
    pageListStart ++;
  }
  
}


const getList = () =>{
  
  axios.post('https://studyapi.programrush.co.kr/study/getBoardList')
  .then(res => {
    
    const json = res.data
    if(json.result == "success"){
      cache.value = json.data
    }
    list.value = [] //보여지는 게시물 리셋
    
    
    let listIdx = (listCunt.value * (currentPage.value )); // 보여질 게시물 index
    for(let i= 0; i < listCunt.value; i++ ){       //게시글 수 만큼 루프
      if(cache.value.length > listIdx) { //
        list.value.push(cache.value[listIdx])
        listIdx ++;
      }
    }

    paging()

  })  
}

getList()

//페이지 번호 클릭시
const page = (e) =>{
  currentPage.value = e  
  getList()
}

//리스트 갯수 수정시
watch(listCunt,(a, b)  =>{
  currentPage.value = 0
  getList()
})

//페이지 처음/끝/이전/다음 버튼 클릭시
const pageArrow = (e) => {
  let movePage = parseInt(currentPage.value)
  //console.log(movePage)

  if(e == 'first'){ //처음으로

    movePage = 0

  } else if(e == 'last'){    //마지막

    movePage = parseInt(totalPage)

  } else if(e == 'prev'){    //이전

    if(currentPage.value <= 10 ){
      movePage = 0
    } else{
      movePage -= 10
    } 
  } else{//다음
  

    if(currentPage.value > totalPage - 10 ){
      movePage = totalPage
    } else{
      movePage += 10
    } 
  }
  page(movePage)
}

</script>

<style scoped>
.boardWrap {width:80%;}
.boardTop {display:flex; justify-content: space-between; align-items: center; margin-bottom:20px;}
.pagination {text-align:center}
</style>
